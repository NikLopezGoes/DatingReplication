import streamlit as st

st.markdown("# NLP")
st.sidebar.markdown("# NLP ")