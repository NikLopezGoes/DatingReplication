import streamlit as st

st.markdown("# Ocean data Visualization")
st.sidebar.markdown("# Ocean data Visualization")