## DAY 1
1. Data Colection : MBTI Dataset 

2. Text analytics 

     i.Data loading 
     
     ii.text cleaning 
     
         a. stopword removal
         b. garbage values (\]}#$)
         c. conversion of cases 
         d. Tokenization 
         e. stemmming 
         f. Lemmetization 
