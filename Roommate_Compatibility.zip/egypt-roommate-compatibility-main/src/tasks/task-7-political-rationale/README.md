<!--
**Rationale: **The main objective of the project is to create a tangible web application to know who to go based on certain stances on political issues. 

**Citations: APA (7th edition) \
**
-->
**Introduction**

<!-- <(This is more of a situation and it is divided into 4 parts)
 -->

    **Previous electoral status**

<!-- 
    (Explains the electoral system in the Philippines Kahit Aquino-related stuff. Add details on the multi-party system dynamics in the Philippines) -->

<!-- 
    (What is the role of technology in the Philippine elections) 
 -->

    **Voter demographics + Persona**


<!-- (Insert the demographics of the voters)
 -->


<!-- 
    (Creating a user-persona, ano ang affinities ng isang tao sa certain characteristics?) -->


<!-- 
    (Include the data on how many voters are in social media)
 -->


    **Campaign propaganda of politicians**

<!-- 
    <!-- (Insert the data regarding certain propagandas of politicians) -->
 -->
**	**
<!-- 
(Explain how personality politics in the Philippines is propagating)
 -->


<!-- **	**(Explain the role of social media in the Philippine elections) -->

**	**

    **Conclusion**

<!-- 
    (Explain that this is a campaign for data-driven and evidence-based elections and that the goal of this project is to create a tool to study the political scenario in the Philippines.)
 -->
**	Scope of the study:**

<!-- **	**(consult with task 1 leaders for the scope of the Project)
 -->
 \
<!-- (Ano ba ang data na kukunin naten at ano ang mga questions na sasagutin naten)	
 -->
	

**References:**
















<!-- **//Notes: **

**/****

*** The goal is to mimic what the \**

*****

*****

***Campaign for data driven and evidence-based elections. **

*****

*****

*****

***Can wawe use this tool to study the voter’s demographic?**

*****

***Who are you as a voter?**

*****

***Which type of personalities to you like**

*****

*****

***Who is saying what in social media?**

*****

***What are the sentiments?**

*****

***What is the political stance in certain issues ansd what needs **

*****

*****

***What are the biases of our study?**

***//** -->
